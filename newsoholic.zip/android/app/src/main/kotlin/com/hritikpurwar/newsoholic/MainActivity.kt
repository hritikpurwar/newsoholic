package com.hritikpurwar.newsoholic

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
